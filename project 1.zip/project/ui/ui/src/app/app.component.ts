import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  selectedFile: File | null = null;
  previewImage: string | null = null;
  canvasJSCode: string = '';

  constructor(private http: HttpClient) { }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }

  uploadFile() {
    if (!this.selectedFile) {
      alert('Please select a file first.');
      return;
    }

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post<any>('http://127.0.0.1:8000/generate-canvas-object', formData).subscribe({
      next: (response) => {
        this.previewImage = response.previewImageBase64;
        this.canvasJSCode = response.canvasJSCode;
      },
      error: (err) => {
        alert('Upload failed: ' + err.error?.error || 'Unknown error');
      }
    });
  }

  copyCode() {
    navigator.clipboard.writeText(this.canvasJSCode).then(() => {
      alert('Code copied to clipboard!');
    });
  }

}
