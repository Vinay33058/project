import base64
from fastapi import UploadFile
from PIL import Image
import fitz  # PyMuPDF
import io
import os

async def convert_file(file: UploadFile):
    content = await file.read()
    filename = file.filename.lower()

    if filename.endswith((".png", ".jpg", ".jpeg")):
        image = Image.open(io.BytesIO(content))
        width, height = image.size
        img_base64 = image_to_base64(image)

    elif filename.endswith(".pdf"):
        doc = fitz.open(stream=content, filetype="pdf")
        page = doc.load_page(0)
        pix = page.get_pixmap()
        img_bytes = pix.tobytes("png")
        image = Image.open(io.BytesIO(img_bytes))
        width, height = image.size
        img_base64 = image_to_base64(image)

    elif filename.endswith(".fig"):
        raise Exception(".fig files are proprietary; export them as SVG/PNG and re-upload.")
    else:
        raise Exception("Unsupported file format")

    canvas_code = generate_canvas_js(width, height, filename)

    return {
        "canvasJSCode": canvas_code,
        "previewImageBase64": img_base64
    }

def generate_canvas_js(width, height, label):
    return f"""
var chart = new CanvasJS.Chart("chartContainer", {{
  title: {{ text: "{label}" }},
  data: [{{
    type: "column",
    dataPoints: [
      {{ x: 10, y: 0 }},
      // You can overlay your image in the chart container manually
    ]
  }}]
}});
chart.render();
""".strip()

def image_to_base64(image: Image.Image):
    buffered = io.BytesIO()
    image.save(buffered, format="PNG")
    img_base64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{img_base64}"
